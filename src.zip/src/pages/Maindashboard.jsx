import React, { useMemo, useState } from "react";
import { Outlet } from "react-router-dom";
import Rightmenu from "../component/Rightmenu";
import {
  FiSearch,
  FiChevronDown,
  FiUser,
  FiBox,
  FiPackage,
  FiAlertTriangle,
  FiUsers,
} from "react-icons/fi";

const tofa = (n) => Number(n).toLocaleString("fa-IR");

const Maindashboard = () => {
  const currentUser = "علی کیوانلو";

  const [transactions, setTransactions] = useState([]);

  const [products, setProducts] = useState([
    { id: 1, type: "گالوانیزه فوم‌دار", material: "گالوانیزه", width: 80, cover: "رنگ‌شده", color: "سفید", length: "۶.۰۰ متر", count: 72, shade: "white" },
    { id: 2, type: "گالوانیزه فوم‌دار", material: "گالوانیزه", width: 80, cover: "رنگ‌شده", color: "سفید", length: "۶.۵۵ متر", count: 103, shade: "cream" },
    { id: 3, type: "گالوانیزه فوم‌دار", material: "گالوانیزه", width: 80, cover: "رنگ‌شده", color: "کرم", length: "۶.۰۰ متر", count: 56, shade: "white" },
    { id: 4, type: "گالوانیزه فوم‌دار", material: "گالوانیزه", width: 80, cover: "رنگ‌شده", color: "مشکی", length: "۶.۵۰ متر", count: 82, shade: "black" },
    { id: 5, type: "آلومینیومی تک‌رول", material: "آلومینیوم", width: 80, cover: "خودرنگ", color: "سفید", length: "۵.۲۵ متر", count: 88, shade: "white" },
    { id: 6, type: "آلومینیومی تک‌رول", material: "آلومینیوم", width: 80, cover: "خودرنگ", color: "مشکی", length: "۶.۰۰ متر", count: 64, shade: "black" },
  ]);

  const [customers, setCustomers] = useState([
    { id: 1, name: "کمپانی الف", phone: "۰۹۱۲۳۴۵۶۷۸۹", address: "تهران", totalPurchase: 3200 },
    { id: 2, name: "مجموعه ب", phone: "۰۹۸۷۶۵۴۳۲۱۰", address: "تبریز", totalPurchase: 1850 },
  ]);

  const stats = useMemo(() => {
    const totalStock = products.reduce((s, p) => s + p.count, 0);
    const lowStock = products.filter((p) => p.count < 10).length;
    return {
      totalStock,
      lowStock,
      productTypes: products.length,
      customersCount: customers.length,
    };
  }, [products, customers]);

  const outletContext = {
    products,
    setProducts,
    customers,
    setCustomers,
    transactions,
    setTransactions,
    currentUser,
  };

  return (
    <div className="maindashboard">
      <div className="right">
        <Rightmenu />
      </div>

      <div className="left">
        <header className="topheader">
          <div className="topheaderbar">
            <div className="topheadersearch">
              <span className="topheadersearchicon">
                <FiSearch />
              </span>
              <input
                className="topheadersearchinput"
                type="text"
                placeholder="جستجو در انبار یا مشتریان..."
              />
            </div>
            <div className="topheaderuser">
              <div className="topheaderavatar">
                <FiUser />
              </div>
              <div className="topheaderusertext">
                <div className="topheadername">{currentUser}</div>
                <div className="topheaderrole">مدیر</div>
              </div>
              <span className="topheaderchevron">
                <FiChevronDown />
              </span>
            </div>
          </div>

          <div className="topheaderwelcome">
            <div className="topheaderwelcomeinfo">
              <div className="topheaderwelcomeicon">
                <FiBox />
              </div>
              <div className="topheaderwelcometexts">
                <h2 className="topheaderwelcometitle">
                  به پنل مدیریت انبار خوش آمدید
                </h2>
                <p className="topheaderwelcometext">
                  در این بخش می‌توانید موجودی تیفه‌ها و مشتریان خود را مدیریت کنید.
                </p>
              </div>
            </div>

            <div className="topheaderstats">
              <div className="topheaderstat topheaderstatpurple">
                <div className="topheaderstaticon">
                  <FiPackage />
                </div>
                <div className="topheaderstatinfo">
                  <div className="topheaderstatlabel">موجودی کل</div>
                  <div className="topheaderstatvalue">{tofa(stats.totalStock)}</div>
                  <div className="topheaderstatunit">شاخه</div>
                </div>
              </div>

              <div className="topheaderstat topheaderstatorange">
                <div className="topheaderstaticon">
                  <FiAlertTriangle />
                </div>
                <div className="topheaderstatinfo">
                  <div className="topheaderstatlabel">موجودی کم</div>
                  <div className="topheaderstatvalue">{tofa(stats.lowStock)}</div>
                </div>
              </div>

              <div className="topheaderstat topheaderstatgreen">
                <div className="topheaderstaticon">
                  <FiBox />
                </div>
                <div className="topheaderstatinfo">
                  <div className="topheaderstatlabel">کل محصولات</div>
                  <div className="topheaderstatvalue">{tofa(stats.productTypes)}</div>
                </div>
              </div>

              <div className="topheaderstat topheaderstatblue">
                <div className="topheaderstaticon">
                  <FiUsers />
                </div>
                <div className="topheaderstatinfo">
                  <div className="topheaderstatlabel">کل مشتریان</div>
                  <div className="topheaderstatvalue">{tofa(stats.customersCount)}</div>
                </div>
              </div>
            </div>
          </div>
        </header>

        <div className="content">
          <Outlet context={outletContext} />
        </div>
      </div>
    </div>
  );
};

export default Maindashboard;