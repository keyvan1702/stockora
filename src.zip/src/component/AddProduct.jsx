import React, { useState } from "react";
import { NavLink } from "react-router-dom";
import { FiPlus, FiBox, FiInfo } from "react-icons/fi";
import { tofa, tolatin, normDecimal, findType, variantLabel } from "../utils/format";
import { useToast } from "./ToastContext";
import Select from "./Select";

const emptyForm = (typeId = "") => ({
  typeId,
  name: "",
  attrs: {},
  count: "",
  shade: "white",
});

const AddProduct = ({ products = [], productTypes = [], actions }) => {
  const toast = useToast();
  const [form, setForm] = useState(emptyForm());
  const [busy, setBusy] = useState(false);

  const type = form.typeId ? findType(productTypes, Number(form.typeId)) : null;
  const typeFields = type?.fields || [];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm({ ...form, [name]: value });
  };

  const handleTypeChange = (v) => {
    setForm({ ...emptyForm(v), shade: form.shade });
  };

  const handleAttr = (field, value) => {
    const clean = field.kind === "number" ? normDecimal(value) : value;
    setForm({ ...form, attrs: { ...form.attrs, [field.key]: clean } });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    if (!type) {
      toast.error("لطفاً نوع محصول را انتخاب کنید!");
      return;
    }
    const missing =
      !form.name.trim() ||
      !form.count.trim() ||
      typeFields.some(
        (f) => f.required && !String(form.attrs[f.key] ?? "").trim()
      );
    if (missing) {
      toast.error("لطفاً تمام فیلدهای الزامی را پر کنید!");
      return;
    }

    const attrs = {};
    typeFields.forEach((f) => {
      const v = form.attrs[f.key];
      if (v === undefined || v === "") attrs[f.key] = "";
      else attrs[f.key] = f.kind === "number" ? Number(v) || 0 : v;
    });

    setBusy(true);
    try {
      await actions.addProduct({
        typeId: type.id,
        name: form.name.trim(),
        attrs,
        count: Number(tolatin(form.count)) || 0,
        shade: form.shade,
      });
      setForm({ ...emptyForm(String(type.id)), shade: "white" });
    } catch {
      /* toast از Maindashboard */
    } finally {
      setBusy(false);
    }
  };

  if (productTypes.length === 0) {
    return (
      <div className="addproductpage">
        <div className="addproducttitle">
          <FiBox />
          <h2>افزودن محصول جدید</h2>
        </div>
        <div className="settingsnote">
          هنوز هیچ نوع محصولی تعریف نشده است. اول از بخش{" "}
          <NavLink to="/settings">تنظیمات</NavLink> یک نوع محصول بسازید و متغیرهایش
          را تعریف کنید.
        </div>
      </div>
    );
  }

  return (
    <div className="addproductpage">
      <div className="addproducttitle">
        <FiBox />
        <h2>افزودن محصول جدید</h2>
      </div>

      <form className="addproductform" onSubmit={handleSubmit}>
        <div className="formrow">
          <div className="formgroup">
            <label>نوع محصول *</label>
            <Select
              value={form.typeId}
              onChange={handleTypeChange}
              placeholder="انتخاب کنید..."
              options={productTypes.map((t) => ({
                value: t.id,
                label: `${t.name} (${tofa(t.fields.length)} متغیر)`,
              }))}
            />
          </div>
          <div className="formgroup">
            <label>نام محصول *</label>
            <input
              type="text"
              name="name"
              placeholder="مثلاً: گالوانیزه فوم‌دار"
              value={form.name}
              onChange={handleChange}
              disabled={!type}
            />
          </div>
        </div>

        {type && (
          <>
            {typeFields.length === 0 ? (
              <div className="settingsnote" style={{ marginBottom: 16 }}>
                <FiInfo />
                این نوع محصول هیچ متغیری ندارد. می‌توانید از بخش{" "}
                <NavLink to="/settings">تنظیمات</NavLink> متغیر اضافه کنید.
              </div>
            ) : (
              <>
                <div className="typefieldstitle" style={{ marginTop: 0 }}>
                  متغیرهای «{type.name}» (از تنظیمات)
                </div>
                {Array.from({ length: Math.ceil(typeFields.length / 2) }, (_, i) =>
                  typeFields.slice(i * 2, i * 2 + 2)
                ).map((pair, idx) => (
                  <div className="formrow" key={idx}>
                    {pair.map((f) => (
                      <div className="formgroup" key={f.key}>
                        <label>
                          {f.label}
                          {f.required ? " *" : ""}
                        </label>
                        {f.kind === "select" ? (
                          <Select
                            value={form.attrs[f.key] || ""}
                            onChange={(v) => handleAttr(f, v)}
                            placeholder="انتخاب کنید..."
                            options={f.options.map((o) => ({ value: o, label: o }))}
                          />
                        ) : (
                          <input
                            type="text"
                            inputMode={f.kind === "number" ? "decimal" : "text"}
                            value={form.attrs[f.key] ?? ""}
                            onChange={(e) => handleAttr(f, e.target.value)}
                          />
                        )}
                      </div>
                    ))}
                  </div>
                ))}
              </>
            )}

            <div className="formrow">
              <div className="formgroup">
                <label>موجودی اولیه ({type.unit}) *</label>
                <input
                  type="text"
                  name="count"
                  placeholder="۰"
                  value={form.count}
                  onChange={handleChange}
                  inputMode="numeric"
                />
              </div>
              <div className="formgroup">
                <label>رنگ نمایش</label>
                <Select
                  value={form.shade}
                  onChange={(v) => setForm({ ...form, shade: v })}
                  options={[
                    { value: "white", label: "سفید" },
                    { value: "cream", label: "کرم" },
                    { value: "black", label: "مشکی" },
                  ]}
                />
              </div>
            </div>
          </>
        )}

        <button type="submit" className="addproductbtn" disabled={!type || busy}>
          <FiPlus />
          {busy ? "در حال افزودن..." : "افزودن محصول"}
        </button>
      </form>

      <div className="addproductlist">
        <h3>محصولات ثبت‌شده ({tofa(products.length)})</h3>
        <div className="productgrid">
          {products.map((p) => {
            const t = findType(productTypes, p.typeId);
            return (
              <div key={p.id} className="productcard">
                <div className={`productshade productshade${p.shade}`}></div>
                <h4>{p.name}</h4>
                <p>
                  {t?.name}
                  {variantLabel(t, p) ? ` · ${variantLabel(t, p)}` : ""}
                </p>
                <span className="productcount">
                  {tofa(p.count)} {t?.unit}
                </span>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default AddProduct;