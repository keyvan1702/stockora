import { createBrowserRouter, useOutletContext } from "react-router-dom";

import Maindashboard from "../pages/Maindashboard";
import Store from "../component/Store";
import TransactionLog from "../component/TransactionLog";
import Customers from "../component/Customers";
import AddProduct from "../component/AddProduct";
import Settings from "../component/Settings";

function InventoryRoute() {
  const {
    products,
    setProducts,
    setTransactions,
    currentUser,
    customers,
    setCustomers,
  } = useOutletContext();

  return (
    <Store
      products={products}
      setProducts={setProducts}
      setTransactions={setTransactions}
      currentUser={currentUser}
      customers={customers}
      setCustomers={setCustomers}
    />
  );
}

function TransactionsRoute() {
  const { transactions } = useOutletContext();
  return <TransactionLog transactions={transactions} />;
}

function CustomersRoute() {
  const { customers, setCustomers } = useOutletContext();
  return <Customers customers={customers} setCustomers={setCustomers} />;
}

function AddProductRoute() {
  const { products, setProducts, setTransactions, currentUser } =
    useOutletContext();

  return (
    <AddProduct
      products={products}
      setProducts={setProducts}
      setTransactions={setTransactions}
      currentUser={currentUser}
    />
  );
}

function SettingsRoute() {
  return <Settings />;
}

const Routers = createBrowserRouter([
  {
    path: "/",
    element: <Maindashboard />,
    children: [
      { index: true, element: <InventoryRoute /> },
      { path: "inventory", element: <InventoryRoute /> },
      { path: "transactions", element: <TransactionsRoute /> },
      { path: "customers", element: <CustomersRoute /> },
      { path: "add-product", element: <AddProductRoute /> },
      { path: "settings", element: <SettingsRoute /> },
    ],
  },
]);

export default Routers;